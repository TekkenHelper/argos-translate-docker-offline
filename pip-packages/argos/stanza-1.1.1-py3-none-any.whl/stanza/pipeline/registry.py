from collections import defaultdict

NAME_TO_PROCESSOR_CLASS = dict()
PIPELINE_NAMES = []
PROCESSOR_VARIANTS = defaultdict(dict)
