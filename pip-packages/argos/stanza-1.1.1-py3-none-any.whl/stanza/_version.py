""" Single source of truth for version number """

__version__ = "1.1.1"
__resources_version__ = '1.1.0'
